<?php
    include('koneksi.php');
    if($_POST['edit']){
        $no = $_POST['no'];
        $tanggal1 = $_POST['tanggal1'];
        $tanggal2 = $_POST['tanggal2'];

        $update = mysqli_query($koneksi, "UPDATE jadwal SET tanggal1='$tanggal1', tanggal2='$tanggal2' WHERE no='$no' ");

        if($update == TRUE){
            echo "berhasil Update";
            header('Location: jadwal.php');
        }
        else{
            echo "Erorr" . $update . "<br>" . $koneksi->error;;
        }
    }

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Smart IoT</title>
    <?php include('bootstrap.php'); ?>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
        $(function() {
            $("#date1").datepicker({
                dateFormat: "dd-mm-yy"
            });
        });
        $(function() {
            $("#date2").datepicker({
                dateFormat: "dd-mm-yy"
            });
        });
    </script>
</head>

<body>
    <?php include('navbar.php'); ?>
    <?php
    include('koneksi.php');
    $data = mysqli_query($koneksi, "SELECT * FROM updateData WHERE no=1");
    $row = mysqli_fetch_array($data);
    ?>
    <br><br><br>
    <div class="container text-center">
        <br>
        <h1><u>Tambah Jadwal</u></h1><br>
        <div class="col-md-10 mx-auto col-lg-5">
            <form class="p-4 p-md-5 border rounded-3 bg-light" action="jadwalTambahProses.php" method="post">
                <div class="form-floating mb-3">
                    <input type="text" class="form-control datepicker" id="date1" name="tanggal1"  required>
                    <label for="floatingInput"> Tanggal1: </label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control datepicker" id="date2" name="tanggal2"  required>
                    <label for="floatingInput"> Tanggal2: </label>
                    <input type="text" class="form-control" id="floatingInput" name="no" hidden>
                </div>
                <button type="submit" name="tambah" value="tambah" class="btn btn-info btn-block text-white">Simpan</button>
            </form>

        </div>

    </div>

</body>

</html>
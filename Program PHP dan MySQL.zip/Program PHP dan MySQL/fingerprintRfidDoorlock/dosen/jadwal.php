<!-- cek apakah sudah login -->
<?php
session_start();
if (($_SESSION['status'] != "login") && ($_SESSION['level'] != "dosen")) {
    header("location: login.php?pesan=belum_login");
}
$email = $_SESSION['email'];
include('koneksi.php');
$anggota = mysqli_query($koneksi, "SELECT * FROM anggota WHERE email='$email'");
$row = mysqli_fetch_array($anggota);
$id = $row['id'];
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fingerprint RFID Doorlock</title>
    <?php include('bootstrap.php'); ?>
</head>

<body>
    <?php include('navbar.php'); ?>
    <<br><br><br>
        <div class="container">
            <br>
            <h1><u>Jadwal</u></h1>
            <a class="btn btn-info text-white" href="jadwalTambah.php" role="button">Tambah Jadwal</a>
            <br><br>
            <!-- TABEL ANGGOTA -->
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">ID Dosen</th>
                        <th scope="col">Tanggal1</th>
                        <th scope="col">Tanggal2</th>
                        <th scope="col">Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $sql = mysqli_query($koneksi, "SELECT * FROM jadwal WHERE id_dosen='$id'");
                    while ($row = mysqli_fetch_array($sql)) {
                    ?>
                        <tr>
                            <th scope="row"> <?php echo $no++; ?> </th>
                            <td> <?php echo $row['id_dosen']; ?> </td>
                            <td> <?php echo $row['tanggal1']; ?> </td>
                            <td> <?php echo $row['tanggal2']; ?> </td>
                            <td>
                                <a href="jadwalEdit.php?no=<?php echo $row['no']; ?>">Edit</a>
                                <a href="jadwalHapus.php?no=<?php echo $row['no']; ?>">Hapus</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>

            </table>
        </div>
        <?php include('footer.php'); ?>
</body>

</html>
<?php
session_start();
if (($_SESSION['status'] != "login") && ($_SESSION['level'] != "dosen")) {
    header("location: login.php?pesan=belum_login");
}
$email = $_SESSION['email'];
include('koneksi.php');
$anggota = mysqli_query($koneksi, "SELECT * FROM anggota WHERE email='$email'");
$row = mysqli_fetch_array($anggota);
$id = $row['id'];

if ($_POST['tambah']) {
    $tanggal1 = $_POST['tanggal1'];
    $tanggal2 = $_POST['tanggal2'];

    $input = mysqli_query($koneksi, "INSERT INTO jadwal VALUES('','$id','$tanggal1','$tanggal2')");
    if ($input == TRUE) {
        echo "berhasil Input";
        header('Location: jadwal.php');
    } else {
        echo "Erorr" . $input . "<br>" . $koneksi->error;;
    }
}

<!DOCTYPE html>
<html lang='id'>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Absensi Fingerprint</title>
  <?php include('bootstrap.php'); ?>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  <script>
    $(function() {
      $("#date1").datepicker({
        dateFormat: "dd-mm-yy"
      });
    });
    $(function() {
      $("#date2").datepicker({
        dateFormat: "dd-mm-yy"
      });
    });
  </script>
</head>

<body>
  <?php include('navbar.php'); ?>
  <?php
  $no = $_GET['no'];
  include('koneksi.php');
  $data = mysqli_query($koneksi, "SELECT * FROM jadwal WHERE no='$no' ");
  $row = mysqli_fetch_array($data);
  ?>
  <br><br><br>
  <div class="container">
    <br>
    <center>
      <h1><u>Edit Jadwal</u></h1><br>
    </center>
    <div class="col-md-10 mx-auto col-lg-5">
      <form class="p-4 p-md-5 border rounded-3 bg-light" action="jadwalEditProses.php" method="post">
        <div class="form-floating mb-3">
          <input type="text" class="form-control datepicker" id="date1" name="tanggal1" value="<?php echo $row['tanggal1']; ?>" required>
          <label for="floatingInput"> Tanggal1: </label>
          <input type="text" class="form-control" id="floatingInput" name="no" value="<?php echo $row['no']; ?>" hidden>
        </div>
        <div class="form-floating mb-3">
          <input type="text" class="form-control datepicker" id="date2" name="tanggal2" value="<?php echo $row['tanggal2']; ?>" required>
          <label for="floatingInput"> Tanggal2: </label>
          <input type="text" class="form-control" id="floatingInput" name="no" value="<?php echo $row['no']; ?>" hidden>
        </div>
        <button type="submit" name="edit" value="edit" class="btn btn-info btn-block text-white">Simpan</button>
      </form>

    </div>

  </div>

  <script>
    $(function() {
      $("#date").datepicker({
        dateFormat: "yy-mm-dd"
      });
    });
  </script>

</body>

</html>
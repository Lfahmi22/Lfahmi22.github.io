<!-- Footer -->
<footer class="page-footer font-small blue">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-5">© <?php echo date('Y'); ?> Copyright:
    <a class="text-primary" href="https://kelasrobot.com"> KelasRobot.com</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
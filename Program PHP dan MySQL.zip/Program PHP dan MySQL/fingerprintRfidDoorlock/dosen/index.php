<!-- cek apakah sudah login -->
<?php
session_start();
if (($_SESSION['status'] != "login") && ($_SESSION['level'] != "dosen")) {
  header("location: login.php?pesan=belum_login");
}
$email = $_SESSION['email'];
include('koneksi.php');
$anggota = mysqli_query($koneksi, "SELECT * FROM anggota WHERE email='$email'");
$row = mysqli_fetch_array($anggota);
$nama = $row['nama'];
?>
<!-- cek apakah sudah login -->
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Fingerprint RFID</title>
  <?php include('bootstrap.php'); ?>
</head>

<body>
  <?php include('navbar.php'); ?>

  <div class="bg-light text-secondary px-4 py-5 text-center">
    <div class="py-5">
      <h1 class="display-5 fw-bold text-dark">Selamat Datang <?php echo $nama; ?></h1>
      <div class="col-lg-6 mx-auto">
        <p class="fs-5 mb-4">
          Disini Anda bisa melakukan berbagai macam hal, seperti melihat data Log data dari semua Mahasiswa.<br>
          Dan juga bisa melihat jadwal, menghapus jadwal, dan juga membuat jadwal baru untuk Mahasiswa.
        </p>
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
          <a href="jadwalTambah.php" type="button" class="btn btn-info btn-lg px-4 me-sm-3 fw-bold  text-white">Buat Jadwal Baru</a>
          <a href="log.php" type="button" class="btn btn-info btn-lg px-4  text-white">Log Data</a>
        </div>
      </div>
    </div>
  </div>

  <?php include('footer.php'); ?>
</body>

</html>
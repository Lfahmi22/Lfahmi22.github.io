-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Apr 2022 pada 06.42
-- Versi server: 10.1.39-MariaDB
-- Versi PHP: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fingerprintrfiddoorlock`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `no` int(255) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`no`, `username`, `password`) VALUES
(1, 'Admin', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `anggota`
--

CREATE TABLE `anggota` (
  `no` int(255) NOT NULL,
  `id` varchar(50) NOT NULL,
  `tag` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nim` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `nohape` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `anggota`
--

INSERT INTO `anggota` (`no`, `id`, `tag`, `nama`, `nim`, `jabatan`, `nohape`, `email`, `password`) VALUES
(1, '1', '01113160157', 'Ajang Rahmat', '-', 'Dosen', '08111810095', 'ajangrahmat@gmail.com', '1234'),
(2, '2', '2824721355', 'Mahasiswa 1', '019087821121', 'Mahasiswa', '08780121312', 'mahasiswa1@gmail.com', '1234'),
(3, '3', '918922357', 'Mahasiswa 2', '213131645231', 'Mahasiswa', '0281021', 'maha@gmail.com', '1231');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE `jadwal` (
  `no` int(255) NOT NULL,
  `id_dosen` varchar(50) NOT NULL,
  `tanggal1` varchar(50) NOT NULL,
  `tanggal2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`no`, `id_dosen`, `tanggal1`, `tanggal2`) VALUES
(6, '1', '05-04-2022', '13-04-2022');

-- --------------------------------------------------------

--
-- Struktur dari tabel `loaddata`
--

CREATE TABLE `loaddata` (
  `no` int(255) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `loaddata`
--

INSERT INTO `loaddata` (`no`, `keterangan`) VALUES
(1, 'Tunggu Sebentar...');

-- --------------------------------------------------------

--
-- Struktur dari tabel `log`
--

CREATE TABLE `log` (
  `no` int(255) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `jam` varchar(50) NOT NULL,
  `id` varchar(50) NOT NULL,
  `tag` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `log`
--

INSERT INTO `log` (`no`, `tanggal`, `jam`, `id`, `tag`, `nama`, `jabatan`) VALUES
(1, '29-03-2022', '16:15:05', '082180807537', '12341782121', 'Ajang Rahmat', 'Dosen'),
(2, '29-03-2022', '17:02:46', '082180807537', '01113160157', 'Ajang Rahmat', 'Dosen'),
(3, '29-03-2022', '18:36:59', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(4, '29-03-2022', '18:37:25', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(5, '30-03-2022', '14:23:00', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(6, '30-03-2022', '14:26:25', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(7, '30-03-2022', '14:26:38', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(8, '30-03-2022', '14:33:20', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(9, '30-03-2022', '14:42:50', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(10, '30-03-2022', '14:43:15', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(11, '30-03-2022', '14:45:14', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(12, '30-03-2022', '14:49:16', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(13, '30-03-2022', '14:51:44', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(14, '30-03-2022', '14:52:30', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(15, '30-03-2022', '15:07:54', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(16, '30-03-2022', '15:33:16', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(17, '30-03-2022', '15:43:48', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(18, '30-03-2022', '15:44:37', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(19, '30-03-2022', '15:45:08', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(20, '30-03-2022', '15:49:50', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(21, '30-03-2022', '15:52:39', '2', '2824721355', 'Mahasiswa 1', 'Mahasiswa'),
(22, '30-03-2022', '15:59:01', '2', '2824721355', 'Mahasiswa 1', 'Mahasiswa'),
(23, '30-03-2022', '15:59:26', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(24, '30-03-2022', '15:59:50', '2', '2824721355', 'Mahasiswa 1', 'Mahasiswa'),
(25, '30-03-2022', '16:01:33', '3', '918922357', 'Mahasiswa 2', 'Mahasiswa'),
(26, '30-03-2022', '16:07:15', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(27, '06-04-2022', '14:37:49', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(28, '06-04-2022', '14:41:19', '1', '01113160157', 'Ajang Rahmat', 'Dosen'),
(29, '12-04-2022', '13:48:18', '2', '2824721355', 'Mahasiswa 1', 'Mahasiswa'),
(30, '12-04-2022', '13:50:39', '2', '2824721355', 'Mahasiswa 1', 'Mahasiswa'),
(31, '12-04-2022', '13:58:16', '2', '2824721355', 'Mahasiswa 1', 'Mahasiswa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tag`
--

CREATE TABLE `tag` (
  `no` int(255) NOT NULL,
  `tag` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `updatedata`
--

CREATE TABLE `updatedata` (
  `no` int(255) NOT NULL,
  `perintah` text NOT NULL,
  `nilai` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `updatedata`
--

INSERT INTO `updatedata` (`no`, `perintah`, `nilai`) VALUES
(1, 'siap', '3');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `loaddata`
--
ALTER TABLE `loaddata`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `tag`
--
ALTER TABLE `tag`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `updatedata`
--
ALTER TABLE `updatedata`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `anggota`
--
ALTER TABLE `anggota`
  MODIFY `no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `loaddata`
--
ALTER TABLE `loaddata`
  MODIFY `no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `log`
--
ALTER TABLE `log`
  MODIFY `no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT untuk tabel `tag`
--
ALTER TABLE `tag`
  MODIFY `no` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `updatedata`
--
ALTER TABLE `updatedata`
  MODIFY `no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
